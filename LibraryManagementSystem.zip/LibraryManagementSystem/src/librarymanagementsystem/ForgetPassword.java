
package librarymanagementsystem;

import Bean.LoginBean;
import Bean.NewAccountBean;
import javax.swing.JOptionPane;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

public class ForgetPassword extends javax.swing.JFrame {

    
    public ForgetPassword() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Username = new javax.swing.JTextField();
        Password = new javax.swing.JTextField();
        Answer = new javax.swing.JTextField();
        CPassword = new javax.swing.JTextField();
        Question = new javax.swing.JComboBox<>();
        Back = new javax.swing.JButton();
        Reset = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Libarary management System");
        setLocation(new java.awt.Point(0, 0));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\idea\\Documents\\NetBeansProjects\\LibraryManagementSystem\\src\\Images\\icons8-books-64.png")); // NOI18N
        jLabel4.setText("Reset Password");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("UserName");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Your Security Question");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Answer");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("New Password");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Confirm Password");

        Username.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        Password.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        Answer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        CPassword.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        Question.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---choose your security question---", "What was your childhood nickname?", "What is the name of your friend?", "What is your favorite team?", "What was your favorite food as a child?" }));

        Back.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Back.setIcon(new javax.swing.ImageIcon("C:\\Users\\idea\\Documents\\NetBeansProjects\\LibraryManagementSystem\\Icons\\icons8-go-back-20.png")); // NOI18N
        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        Reset.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Reset.setIcon(new javax.swing.ImageIcon("C:\\Users\\idea\\Documents\\NetBeansProjects\\LibraryManagementSystem\\Icons\\Submit.png")); // NOI18N
        Reset.setText("Reset");
        Reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel3)
                                .addComponent(jLabel5))
                            .addGap(76, 76, 76))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addGap(54, 54, 54)))
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(Back, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Username)
                    .addComponent(Answer)
                    .addComponent(Password)
                    .addComponent(CPassword)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 154, Short.MAX_VALUE)
                        .addComponent(Reset, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(Question, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(38, 38, 38))
            .addGroup(layout.createSequentialGroup()
                .addGap(116, 116, 116)
                .addComponent(jLabel4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel4)
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Username, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Question, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Answer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(CPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Back)
                    .addComponent(Reset))
                .addGap(31, 31, 31))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    String Username1=null;
    String Question1=null;
    String Answer1=null;
    String Password1=null;
    String CPassword1=null;
    private void ResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetActionPerformed
        
       Username1= Username.getText();
       Question1=(String) Question.getSelectedItem();
       Answer1= Answer.getText();
       Password1= Password.getText();
       CPassword1= CPassword.getText();
       setPass();
    }//GEN-LAST:event_ResetActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        setVisible(false);
        Login login=new Login();
        login.setVisible(true);
    }//GEN-LAST:event_BackActionPerformed
        
    public void setPass()
    {
       GetSession session=new GetSession();
       Session s=session.getSession();
       
       Criteria query=s.createCriteria(NewAccountBean.class);
       query.add(Restrictions.eq("Username", Username1));
       NewAccountBean lb=(NewAccountBean)query.uniqueResult();
       
       Criteria query1=s.createCriteria(LoginBean.class);
       query1.add(Restrictions.eq("UserName", Username1));
       LoginBean log=(LoginBean)query1.uniqueResult();
       
       if(lb!=null)
       {
           if(Question1.equals(lb.getQuestion()) && Answer1.equals(lb.getAnswer()))
           {
                 if(Password1.equals(CPassword1) && Password1!=null)
                 {
                     lb.setPassword(Password1);
                     log.setPassword(Password1);
                     s.update(lb);
                     s.update(log);
                     JOptionPane.showMessageDialog(null, "Password Updated!!");
                 }   
                 else
                 {
                      JOptionPane.showMessageDialog(null, "Password and Confirm password are not same!!");
                 }
           }
           else
           {
                JOptionPane.showMessageDialog(null, "Incorrect question or answer");
           }
       }
       else
       {
           JOptionPane.showMessageDialog(null, "Invalide UserName");
       }
       s.beginTransaction().commit();
       s.close();
    }
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ForgetPassword().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Answer;
    private javax.swing.JButton Back;
    private javax.swing.JTextField CPassword;
    private javax.swing.JTextField Password;
    private javax.swing.JComboBox<String> Question;
    private javax.swing.JButton Reset;
    private javax.swing.JTextField Username;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    // End of variables declaration//GEN-END:variables
}
