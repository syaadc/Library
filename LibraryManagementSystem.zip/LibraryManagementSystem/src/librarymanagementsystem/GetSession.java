
package librarymanagementsystem;


import Bean.IssueBookBean;
import Bean.LoginBean;
import Bean.NewAccountBean;
import Bean.NewBookBean;
import Bean.NewStudentBean;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;


public class GetSession 
{
    
    public Session getSession()
    {
        Configuration cf=new Configuration()
                .configure("librarymanagementsystem/hibernate.cfg.xml")
                .addAnnotatedClass(NewAccountBean.class)
                .addAnnotatedClass(LoginBean.class)
                .addAnnotatedClass(NewBookBean.class)
                .addAnnotatedClass(NewStudentBean.class)
                .addAnnotatedClass(IssueBookBean.class);
        
        SessionFactory sf=cf.buildSessionFactory();
        Session session=sf.openSession();
        return  session;
    }
}
