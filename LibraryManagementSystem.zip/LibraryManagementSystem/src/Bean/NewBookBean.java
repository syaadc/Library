
package Bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Books")
public class NewBookBean 
{
     @Id
     private int BookId=0;
     private String Name;
     private String Edition;
     private String Publisher;
     private long Pages=0;
     private Double Price=0.0;

    public int getBookId() {
        return BookId;
    }

    public void setBookId(int BookId) {
        this.BookId = BookId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getEdition() {
        return Edition;
    }

    public void setEdition(String Edition) {
        this.Edition = Edition;
    }

    public String getPublisher() {
        return Publisher;
    }

    public void setPublisher(String Publisher) {
        this.Publisher = Publisher;
    }

    public long getPages() {
        return Pages;
    }

    public void setPages(long Pages) {
        this.Pages = Pages;
    }

    public Double getPrice() {
        return Price;
    }

    public void setPrice(Double Price) {
        this.Price = Price;
    }

    @Override
    public String toString() {
        return "NewBookBean{" + "BookId=" + BookId + ", Name=" + Name + ", Edition=" + Edition + ", Publisher=" + Publisher + ", Pages=" + Pages + ", Price=" + Price + '}';
    }
     
     
}
