
package Bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Signup")
public class NewAccountBean {
    
    @Id
    @GeneratedValue
    private int Id;
    private String Username;
    private String Password;

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }
    private String  Fullname;
    private String  Question;
    private String  Answer;
    private Long Mobileno;
    @OneToOne
    private LoginBean login;

    public LoginBean getLogin() {
        return login;
    }

    public void setLogin(LoginBean login) {
        this.login = login;
    }
    
    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getFullname() {
        return Fullname;
    }

    public void setFullname(String Fullname) {
        this.Fullname = Fullname;
    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String Question) {
        this.Question = Question;
    }

    public String getAnswer() {
        return Answer;
    }

    public void setAnswer(String Answer) {
        this.Answer = Answer;
    }

    public Long getMobileno() {
        return Mobileno;
    }

    public void setMobileno(Long Mobileno) {
        this.Mobileno = Mobileno;
    }

    @Override
    public String toString() {
        return "NewAccountBean{" + "Id=" + Id + ", Username=" + Username + ", Password=" + Password + ", Fullname=" + Fullname + ", Question=" + Question + ", Answer=" + Answer + ", Mobileno=" + Mobileno + ", login=" + login + '}';
    }
    
    
    
}
