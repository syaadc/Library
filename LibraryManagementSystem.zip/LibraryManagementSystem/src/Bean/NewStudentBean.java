
package Bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "StudentDetail")
public class NewStudentBean 
{
    @Id
    private int sid=0;
    private String name;
    private String father;
    private String course;
    private String branch;
    private int year=0;
    private int samester=0;

    public int getSid() {
        return sid;
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFather() {
        return father;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getSamester() {
        return samester;
    }

    public void setSamester(int samester) {
        this.samester = samester;
    }

    @Override
    public String toString() {
        return "NewStudentBean{" + "sid=" + sid + ", name=" + name + ", father=" + father + ", course=" + course + ", branch=" + branch + ", year=" + year + ", samester=" + samester + '}';
    }  
}
