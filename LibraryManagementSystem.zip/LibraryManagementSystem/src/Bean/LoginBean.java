
package Bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Login")
public class LoginBean 
{

    @Id
    @GeneratedValue
     private int LId;
     private String UserName;
     private String Password;

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String UserName) {
        this.UserName = UserName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public int getLId() {
        return LId;
    }

    public void setLId(int LId) {
        this.LId = LId;
    }

    @Override
    public String toString() {
        return "LoginBean{" + "LId=" + LId + ", UserName=" + UserName + ", Password=" + Password + '}';
    }
     
}
